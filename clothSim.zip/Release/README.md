The project was made in C++ using Visual Studio
We started from an already made OpenGL base that uses freeGLUT

The aim of this project was to research and implement ourselves Clothing simulation techniques from well known papers


I implemented 
	a few techniques for realistic stiffness
	a bounding volume hierarchy and its rendering
	the wind
	self collision handling (collisions didn't work out as planned ... :') )  
	And made a simple UI with the GLUI library!